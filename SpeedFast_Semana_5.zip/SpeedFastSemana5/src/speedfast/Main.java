package speedfast;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

/**
 * Clase principal del sistema SpeedFast.
 */
public class Main {

    public static void main(String[] args) {

        ZonaDeCarga zonaDeCarga = new ZonaDeCarga();

        zonaDeCarga.agregarPedido(new Pedido(1, "Av. Central 123", EstadoPedido.PENDIENTE));
        zonaDeCarga.agregarPedido(new Pedido(2, "Calle Norte 456", EstadoPedido.PENDIENTE));
        zonaDeCarga.agregarPedido(new Pedido(3, "Pasaje Sur 789", EstadoPedido.PENDIENTE));
        zonaDeCarga.agregarPedido(new Pedido(4, "Ruta 5 km 10", EstadoPedido.PENDIENTE));
        zonaDeCarga.agregarPedido(new Pedido(5, "Los Aromos 222", EstadoPedido.PENDIENTE));

        ExecutorService executor = Executors.newFixedThreadPool(3);
        executor.submit(new Repartidor("Repartidor-1", zonaDeCarga));
        executor.submit(new Repartidor("Repartidor-2", zonaDeCarga));
        executor.submit(new Repartidor("Repartidor-3", zonaDeCarga));

        executor.shutdown();

        try {
            executor.awaitTermination(2, TimeUnit.MINUTES);
        } catch (InterruptedException e) {
            executor.shutdownNow();
            Thread.currentThread().interrupt();
        }

        System.out.println("Todos los pedidos han sido entregados correctamente");
    }
}
