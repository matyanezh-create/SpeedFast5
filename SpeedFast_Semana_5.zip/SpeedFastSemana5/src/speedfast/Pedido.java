package speedfast;

/**
 * Clase que representa un pedido dentro del sistema SpeedFast.
 */
public class Pedido {

    private int id;
    private String direccionEntrega;
    private EstadoPedido estado;

    public Pedido(int id, String direccionEntrega, EstadoPedido estado) {
        this.id = id;
        this.direccionEntrega = direccionEntrega;
        this.estado = estado;
    }

    public int getId() {
        return id;
    }

    public String getDireccionEntrega() {
        return direccionEntrega;
    }

    public EstadoPedido getEstado() {
        return estado;
    }

    /**
     * Actualiza el estado del pedido.
     */
    public void setEstado(EstadoPedido nuevoEstado) {
        this.estado = nuevoEstado;
    }

    /**
     * Representación textual del pedido.
     */
    @Override
    public String toString() {
        return "Pedido{id=" + id +
                ", direccionEntrega=" + direccionEntrega +
                ", estado=" + estado +
                "}";
    }
}
