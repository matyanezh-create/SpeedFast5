package speedfast;

import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;

/**
 * Recurso compartido que representa la zona de carga.
 */
public class ZonaDeCarga {

    private final BlockingQueue<Pedido> cola = new LinkedBlockingQueue<>();

    public synchronized void agregarPedido(Pedido p) {
        cola.offer(p);
        notifyAll();
    }

    public synchronized Pedido retirarPedido() {
        return cola.poll();
    }
}
