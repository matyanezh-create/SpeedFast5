package speedfast;

/**
 * Enum que representa los posibles estados de un pedido.
 */
public enum EstadoPedido {
    PENDIENTE,
    EN_REPARTO,
    ENTREGADO
}
